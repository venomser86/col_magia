﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persons_.Data.Migrations
{
    public partial class MigrationC : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LastName",
                table: "PersonsData");

            migrationBuilder.DropColumn(
                name: "NDoc",
                table: "PersonsData");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "PersonsData",
                nullable: true,
                oldClrType: typeof(string),
                oldMaxLength: 50);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "PersonsData",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LastName",
                table: "PersonsData",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "NDoc",
                table: "PersonsData",
                nullable: false,
                defaultValue: 0);
        }
    }
}
