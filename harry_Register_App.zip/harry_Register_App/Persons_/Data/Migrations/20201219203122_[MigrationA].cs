﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persons_.Data.Migrations
{
    public partial class MigrationA : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "LastName",
                table: "PersonsData",
                maxLength: 50,
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LastName",
                table: "PersonsData");
        }
    }
}
