﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persons_.Data.Migrations
{
    public partial class Migration07 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "nDoc",
                table: "PersonsData",
                newName: "NDoc");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "NDoc",
                table: "PersonsData",
                newName: "nDoc");
        }
    }
}
