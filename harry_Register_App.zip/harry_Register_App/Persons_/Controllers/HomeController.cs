﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Persons_.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;

namespace Persons_.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.ListadoCasasHogwards = ObtenerListado();

            List<SelectListItem> items = new List<SelectListItem>();
            items.Add(new SelectListItem { Text = "gryffindor", Value = "gryffindor" });
            items.Add(new SelectListItem { Text = "hufflepuff", Value = "hufflepuff" });
            items.Add(new SelectListItem { Text = "ravenclaw", Value = "ravenclaw" });
            items.Add(new SelectListItem { Text = "ddravenclaw", Value = "gryffindor" });
            

            AlbumsList selectCasa = new AlbumsList();
            selectCasa.CASAS = items;

            ViewData["Options"] = selectCasa;


            
            return View(selectCasa);
        }

        /// <summary>
        /// Abouts the specified model.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <returns></returns>
        [HttpPost]
        //public ActionResult VisualizeAlbum(AlbumsList model)
        public ActionResult FiltroCasaEstudiantes(AlbumsList model)
        {
            string alfa = ViewBag.ListadoCasasHogwards;

            return View(ObtenerInfoServicio(model.SelectedCategory));
            //return View(ObtenerInfoServicio(alfa));
            //return View(ObtenerInfoServicio(model.CASAS.ToString()));
        }

        public IActionResult Profesores()
        {
            return View(ObtenerInfoServicioProfesores());
        }
        

        public IActionResult Estudiantes(AlbumsList model)
        {
            return View(ObtenerInfoServicioEstudiantes());
        }

        [HttpPost]
        public string SaveResults(List<int> location_code)
        {

            if (location_code != null)
            {
                return string.Join(",", location_code);
            }
            else
            {
                return "No values are selected";
            }
        }

        public class AlbumsList
        {
            public IEnumerable<SelectListItem> CASAS { set; get; }

            public string SelectedCategory { set; get; }
        }


        public List<SelectListItem> ObtenerListado()
        {
            return new List<SelectListItem>()
            {
                new SelectListItem(){
                Text ="Gryffindor",
                Value="gryffindor"
                },
                new SelectListItem(){
                Text ="Hufflepuff",
                Value="hufflepuff"
                },
                new SelectListItem(){
                Text ="Ravenclaw",
                Value="ravenclaw"
                },
                new SelectListItem(){
                Text ="Slytherin",
                Value="slytherin"
                }
            };
        }


        public List<Root> ListaServicio = new List<Root>();

        
        public List<Root> ObtenerInfoServicio(string casaConsultada)
        {
            string url = "http://hp-api.herokuapp.com/api/characters/house/";

            if (casaConsultada == null)
            {
                casaConsultada = "ravenclaw";
            }

            url = url + casaConsultada;

            LlamadoAjusteservicioHP(url);
            return ListaServicio;
        }

        public List<Root> ObtenerInfoServicioEstudiantes()
        {
            string url = "http://hp-api.herokuapp.com/api/characters/students";

            LlamadoAjusteservicioHP(url);
            return ListaServicio;
        }

        public List<Root> ObtenerInfoServicioProfesores()
        {
            string url = "http://hp-api.herokuapp.com/api/characters/staff";

            LlamadoAjusteservicioHP(url);
            return ListaServicio;
        }



        private void LlamadoAjusteservicioHP(string url)
        {
            WebClient client = new WebClient();
            string reply = client.DownloadString(url);
            ListaServicio = JsonConvert.DeserializeObject<List<Root>>(reply);

            foreach (var Item in ListaServicio)
            {
                if (Item.yearOfBirth == "")
                {
                    Item.yearOfBirth = "Edad desconocida";
                }
                else
                {
                    int edad = 2020 - Int32.Parse(Item.yearOfBirth);
                    Item.yearOfBirth = edad.ToString();
                }

                if (Item.patronus == "")
                {
                    Item.patronus = "Patronus desconocido";
                }

                if (Item.eyeColour == "")
                {
                    Item.eyeColour = "Color de ojos desconocido";
                }
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        //private async Task CreateRoles(IServiceProvider serviceProvider)
        //{
        //    var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        //}

        /// <summary>
        /// Contacts this instance.
        /// </summary>
        /// <returns></returns>
        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";
            return View();
        }

        public IActionResult About()
        {
            //ViewData["Message"] = "Your contact page.";
            return View();
        }


    }
}
