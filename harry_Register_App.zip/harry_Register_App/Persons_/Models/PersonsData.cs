﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Persons_.Models
{
    public class PersonsData
    {
        public int ID { get; set; }

        [Display(Name = "Nombre")]
        [StringLength(20)]
        [RegularExpression(@"(^(?=.{1,20}$)[A-ZÁÉÍÓÚ][a-zñáéíóú]+(?: [A-ZÁÉÍÓÚ][a-zñáéíóú]+)?$)",
           ErrorMessage = "El formato del Nombre ingresado no es correcto. Deben ser mínimo 1 y máximo 20 caracteres. La primera letra debe estar Mayúsculas")]

        public String Name { get; set; }

        [Display(Name = "Apellido")]
        [StringLength(20)]
        [RegularExpression(@"(^(?=.{1,20}$)[A-ZÁÉÍÓÚ][a-zñáéíóú]+(?: [A-ZÁÉÍÓÚ][a-zñáéíóú]+)?$)",
            ErrorMessage = "El formato del Apellido ingresado no es correcto. Deben ser mínimo 1 y máximo 20 caracteres. La primera letra debe estar Mayúsculas")]
        
        public String LastName { get; set; }

        [Display(Name = "Edad")]
        //[StringLength(2, MinimumLength = 1)]
        [RegularExpression(@"(^(0?[0-9]{1,2})$)",
            ErrorMessage = "El formato de la edad ingresada no es correcto. Deben ser máximo 2 dígitos")]
        public int Age { get; set; }

        [Display(Name = "Número de Documento")]
        //[StringLength(10)] //Document Number
        [RegularExpression(@"(^(0?[0-9]{1,10})$)",
            ErrorMessage = "El formato del número de documento ingresado no es correcto. Deben ser máximo 10 dígitos")]

        public int Sex { get; set; }

        //[Display(Name = "Casa")]
        //public string CasaSeleccionada { get; set; }
        //public IEnumerable<SelectListItem> CasasDisponibles { get; set; }

    }
}
