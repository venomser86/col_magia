﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Persons_.Models
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Wand
    {
        public string wood { get; set; }
        public string core { get; set; }
        public string length { get; set; }
    }

    public class Root
    {
        public string name { get; set; }
        public string species { get; set; }
        public string gender { get; set; }
        public string house { get; set; }
        public string dateOfBirth { get; set; }
        public string yearOfBirth { get; set; }
        public string ancestry { get; set; }
        public string eyeColour { get; set; }
        public string hairColour { get; set; }
        public Wand wand { get; set; }
        public string patronus { get; set; }
        public bool hogwartsStudent { get; set; }
        public bool hogwartsStaff { get; set; }
        public string actor { get; set; }
        public bool alive { get; set; }
        public string image { get; set; }

        public IEnumerable<SelectListItem> CASAS { set; get; }

        public string SelectedCategory { set; get; }
    }

    //public List<SelectListItem> ObtenerListado()
    //{
    //    return new List<SelectListItem>()
    //        {
    //            new SelectListItem(){
    //            Text ="gryffindor",
    //            Value="gryffindor"
    //            },
    //            new SelectListItem(){
    //            Text ="ravenclaw",
    //            Value="ravenclaw"
    //            },
    //            new SelectListItem(){
    //            Text ="dois",
    //            Value="dois"
    //            }
    //        };
    //}
}
